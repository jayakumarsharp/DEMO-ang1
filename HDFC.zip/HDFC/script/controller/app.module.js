(function () {
'use strict';
    
// app.module.js
angular
  .module('myApp', ['moment-picker', 'smartTable.table', 'ui.grid', 'ui.grid.selection', 'ui.grid.autoResize', 'ui.grid.resizeColumns']);

}());