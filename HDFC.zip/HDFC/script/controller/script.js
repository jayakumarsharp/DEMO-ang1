(function () {
  'use strict';

  angular
    .module('myApp')
    .controller('mainCtrl', mainCtrl);

  mainCtrl.$inject = ['$scope', '$interval'];

  function mainCtrl(scope, $interval) {
    var vm = this;
    vm.onLoad = onLoad;

    function onLoad() {
      var vm = this;
      vm.ccd = {
        dataEnrichment: {
          "DAS": "Started",
          "xsellTag": "PL",
          "ccXSell": "54322",
          "PA": "Process",
          "CT": "ATO",
          "ALXSell": "5432",
          "Triggers": "Manual",
          "CC": "HDFC2345",
          "PLXSell": "5423",
          "CusCatgy": "Eligible"
        },
        segement: {
          "RH": "Chennai",
          "product": "Credit Card",
          "channel": "Call",
          "segment": "Credit",
          "subSegment": "Saving Account"
        },
        costumerDetails: {
          "city": "Chennai",
          "state": "Tamilnadu",
          "zipcode": "600100",
        },
        bankingdetails: {
          "DWHID": "457125",
          "LOANCUSTID": "4571274",
          "CARDNO": "47557",
          "FWCUSTID": "475124",
          "LOANNO": "4521754885",
          "FWACCTNO": "4571544",
          "CARDCUSTID": "1222",
        }
      };

      vm.complaintEntry = { 
        "complainantName": "21234",
        "accountNumber": "121212121",
        "contactNumber": "9000000000",
        "classificationUnit": "Credit",
        "resolvingUnit": ["L1","L2","L3"],
        "subCategory": ["APP Fixed", "App Waiting", "App Closed", "App Reopened"],
        "customerCity": "Chennai",
        "custNameOnCard": "Kumar varuman",
        "existingCustomer": ["yes","No"],
        "docketNumber": "124578",
        "email": "Testing@gmail.com",
        "serviceType": ["Liability","Phone Call","Agent","Manual Entry","Mail"],
        "resolvingBranch": ["Chennai","Maduri","Thrichy","Salem","Krishnagiri"],
        "complaintSource": ["Call","Mail","Manual"],
        "addlInfo": "Software",
        "detailedSuggestion": "Issue on card details",
        "customerID": "134857",
        "mobileNumber": "9000000000",
        "loggingBranch": "Chennai",
        "priority": ["Critical","Major","Minor","Significant"],
        "category": ["RD","FD","Saving","Current","Credit"],
        "complaintNature": "call",
        "cardNumber": "12333322",
      };
      
      vm.mainData = {
        customerName: 'Jones',
        custMobile: '9988776655',
        custCity: 'Chennai',
        custState: 'Tamilnadu'
      };
      vm.rowCollection = [
        {
          campaignName: 'Pred-Dial', campaingDescription: 'Pred-Dial',
          validityFrom: 'NA', validatyTo: 'NA', status: 'Running',
          branch: 'CHEN', function: 'CARDS', product: 'CREDIT CARD',
          custommerName: 'DORMANT'
        }
      ];
      scope.gridOptions.data = [
        {
          campaignName: 'Pred-Dial', campaingDescription: 'Pred-Dial',
          validityFrom: 'NA', validatyTo: 'NA', status: 'Running',
          branch: 'CHEN', function: 'CARDS', product: 'CREDIT CARD',
          custommerName: 'DORMANT'
        }
      ];
      scope.xSellgridOptions.data = [
        {
          SNo: '1', XSell: 'Current Account',
          Branch: 'Chennai', DateTime: '2017-11-23 06:52:22', CustName: 'Hdfc User',
          Mobile: '9844574521', City: 'Chennai', State: 'TamilNadu',
          AgentMemo: 'test', CustomerMemo: 'test', Remarks: 'test'
        }
      ];
      scope.upSellgridOptions.data = [
        {
          SNo: '1', UpSell: 'Current Account',
          Branch: 'Chennai', DateTime: '2017-11-23 06:52:22', CustName: 'Hdfc User',
          Mobile: '9844574521', City: 'Chennai', State: 'TamilNadu',
          AgentMemo: 'test', CustomerMemo: 'test', Remarks: 'test'
        }
      ];
      
      vm.tableData = [
        { "id1": "UN ID", "id2": "", "id3": "SEGEMENT", "id4": "DBC", 'color': 'black', 'bgcolor': 'springgreen', 'bgcolor1': 'red'},
        { "id1": "ELIGIBILITY", "id2": "-000018000", "id3": "CUSTOMER NAME", "id4": "Round-8-59525660", 'color': 'black', 'bgcolor': 'yellow', 'bgcolor1': 'pink' },
        { "id1": "DWHID", "id2": "", "id3": "SUB SEGMENT", "id4": "AL_XSELL", 'color': 'black', 'bgcolor': '#d0e9c6' , 'bgcolor1': '#F778A1' },
        { "id1": "XSell FLAG", "id2": "8574255256", "id3": "Xsell AL OFFER", "id4": "", 'color': 'black', 'bgcolor': 'yellow', 'bgcolor1': 'yellow' },
        { "id1": "XSell PL OFFER", "id2": "", "id3": "Xsell CC OFFER", "id4": "", 'color': 'black', 'bgcolor': 'yellow', 'bgcolor1': 'yellow' },
        { "id1": "EMAIL OPEN FLAG", "id2": "", "id3": "REGION_HUBCITY", "id4": "CHEN", 'color': 'black', 'bgcolor': 'yellow', 'bgcolor1': '#E5E4E2' },
        { "id1": "FWACCTNO", "id2": "", "id3": "LOANCUSTID", "id4": "", 'color': 'black', 'bgcolor': '#d0e9c6', 'bgcolor1': '#d0e9c6' },
        { "id1": "LOANNO", "id2": "", "id3": "CARDCUSTID", "id4": "", 'color': 'black', 'bgcolor': '#d0e9c6', 'bgcolor1': '#d0e9c6' },
        { "id1": "CARDNO", "id2": "", "id3": "ADD1", "id4": "ADD1", 'color': 'black', 'bgcolor': '#d0e9c6', 'bgcolor1': 'pink' },
        { "id1": "ADD2", "id2": "ADD2", "id3": "ADD3", "id4": "ADD3", 'color': 'black', 'bgcolor': 'pink', 'bgcolor1': 'pink' },
        { "id1": "ADD4", "id2": "ADD4", "id3": "CITY", "id4": "CITY", 'color': 'black', 'bgcolor': 'pink', 'bgcolor1': 'pink' },
        { "id1": "STATE", "id2": "STATE", "id3": "CUSTOMER_TYPE", "id4": "NCSRM", 'color': 'black', 'bgcolor': 'pink' , 'bgcolor1': 'pink' },
        { "id1": "CUSTOMER_CATEGORY", "id2": "", "id3": "CORP SAL OFFER", "id4": "", 'color': 'black', 'bgcolor': 'pink' , 'bgcolor1': '#d0e9c6' },
        { "id1": "OCCUPATION", "id2": "RSW199UOC8", "id3": "DESIGNATION", "id4": "DORMANT", 'color': 'black', 'bgcolor': 'pink' , 'bgcolor1': 'pink' },
        { "id1": "SEX", "id2": "NOT ELIGIBLE", "id3": "DOB", "id4": "NOT ELIGIBLE", 'color': 'black', 'bgcolor': 'pink' , 'bgcolor1': 'pink' },
        { "id1": "INCOME", "id2": "N", "id3": "YRS_CUR_EMP_BUS", "id4": "C", 'color': 'black', 'bgcolor': 'pink' , 'bgcolor1': 'pink' },
        { "id1": "PROPERTY", "id2": "A_H", "id3": "EMAIL_ID", "id4": "WL", 'color': 'black', 'bgcolor': 'pink' , 'bgcolor1': 'pink' },
        { "id1": "REMARKS", "id2": "TEST REMARKS UPDATED FOR SMAPLE UPLOAD ..TEST REMARKS UPADTED FOR SMAPLE UPLOAD", "id3": "OFF_EMAIL", "id4": "I", 'color': 'black', 'bgcolor': 'white' , 'bgcolor1': 'pink' },
        { "id1": "COMPANY_CODE", "id2": "AGRICULTURE", "id3": "COMAPANY_NAME", "id4": "I", 'color': 'black', 'bgcolor': 'pink' , 'bgcolor1': 'pink' },
        { "id1": "PROMO_NAME", "id2": "F", "id3": "PROMO_CODE", "id4": "CASA", 'color': 'black', 'bgcolor': 'pink' , 'bgcolor1': 'yellow' },
        { "id1": "SEGMENT", "id2": "1", "id3": "INT_RATES", "id4": "LL", 'color': 'black', 'bgcolor': 'yellow' , 'bgcolor1': 'yellow' },
        { "id1": "EST_LOAN_AMT", "id2": "A2: COMPACT", "id3": "GROSS_AMT", "id4": "C >709", 'color': 'black', 'bgcolor': '#d0e9c6' , 'bgcolor1': 'yellow' },
        { "id1": "TOP_UP_AMT", "id2": " MARUTI ALTO LXI", "id3": "TENURE", "id4": "A2: COMPACT", 'color': 'black', 'bgcolor': 'yellow' , 'bgcolor1': 'yellow' },
        { "id1": "PROCESSING_FEE", "id2": "CRM", "id3": "CAMPAING_TYPE", "id4": "FINWARECASA", 'color': 'black', 'bgcolor': 'yellow' , 'bgcolor1': 'yellow' },
        { "id1": "SCORE", "id2": "", "id3": "177", "id4": "SASAL", 'color': 'black', 'bgcolor': '#d0e9c6' , 'bgcolor1': 'yellow' },
        { "id1": "CHQ_MIS", "id2": "15+", "id3": "TOKEN_NO", "id4": "UN_CARDED", 'color': 'black', 'bgcolor': 'yellow' , 'bgcolor1': '#E5E4E2' },
        { "id1": "REP FLAG", "id2": "d012", "id3": "SOURCE", "id4": "PNCHKL2_HRY", 'color': 'black', 'bgcolor': '#F778A1' , 'bgcolor1': '#E5E4E2' },
        { "id1": "BRANCH CODE", "id2": "y", "id3": "PRIORITY", "id4": "Y", 'color': 'black', 'bgcolor': '#d0e9c6' , 'bgcolor1': '#d0e9c6' },
        { "id1": "LEADID", "id2": "59525660", "id3": " LEAD DATE", "id4": "Y", 'color': 'black', 'bgcolor': '#d0e9c6' , 'bgcolor1': '#d0e9c6' },
        { "id1": "BRANCH NAME", "id2": "NOT ELIGIBLE", "id3": "Field37", "id4": "", 'color': 'black', 'bgcolor': '#d0e9c6' , 'bgcolor1': 'white' }
      ];

      vm.optionData = ["Interested", "Not Interested", "Start", "Progress", "Pending","Closed"];
      vm.optionData = {
        responseCategory: ["Interested", "Not Interested", "Start", "Progress", "Pending","Closed"],
        callResponse: ["Happy", "Satisfied", "HDFC bank Service not satisfactory"],
        callMode: ["Agent","Inbound","Outbound"],
        serviceType: ["Liability","Phone Call","Agent","Manual Entry","Mail"],
        category: ["RD","FD","Saving","Current","Credit"],
        subCategory: ["APP Fixed", "App Waiting", "App Closed", "App Reopened"],
        xSellProduct: ["Current Account", "Saving Account", "Demant Account"],
        xBranch: ["Chennai", "Salem", "Thrichy", "Kovai","Krishnagiri"],
        upSellProduct: ["Current Account", "Saving Account", "Demant Account"],
        upBranch: ["Chennai", "Salem", "Thrichy", "Kovai","Krishnagiri"],

      } 
      vm.appFixGridOptions.data = [
        {
          field: 'Field Vaalue', product: 'Field Vaalue',
          field1: 'Field Vaalue', dapid: 'NA', campaingName: 'Field Vaalue',
          appFixDate: 'Field Vaalue', subProduct: 'Field Vaalue'
        },
        {
          field: 'Fie4ld Vaalue', product: 'Fiel4d Vaalue',
          field1: 'Fie4ld Vaalue', dapid: 'N4A', campaingName: 'Fiel4d Vaalue',
          appFixDate: 'Fiel4d Vaalue', subProduct: 'Fie4ld Vaalue'
        },
        {
          field: 'Field Va3alue', product: 'Fie3ld Vaalue',
          field1: 'Field Va3alue', dapid: 'N3A', campaingName: 'Fi3eld Vaalue',
          appFixDate: 'Fie3ld Vaalue', subProduct: 'Field Vaalue'
        },
        {
          field: 'Field Va1alue', product: 'Field Vaa1lue',
          field1: 'Field Va1alue', dapid: 'N1A', campaingName: 'Field V1aalue',
          appFixDate: 'Fiel1d Vaa1lue', subProduct: 'Field Va1alue'
        }, {
          field: 'Field Vaa2lue', product: 'Fie2ld Vaalue',
          field1: 'Field Va2alue', dapid: 'N2A', campaingName: 'Field Va2alue',
          appFixDate: 'F2ield Vaalue', subProduct: 'Fie2ld Vaalue'
        }
      ];
    }

    /**Customer RelationShip**/
    scope.custRelationship = {};
    scope.IsShowCustRelationGrid = false;
    scope.custRelRowCollection = [];

    scope.columnCollection = [
      {
        label: 'CampaignName',
        map: 'campaignName'
      },
      {
        label: 'CampaingDescription',
        map: 'campaingDescription'
      },
      {
        label: 'ValidityFrom',
        map: 'validityFrom'
      },
      {
        label: 'ValidatyTo',
        map: 'validatyTo'
      },
      {
        label: 'Status',
        map: 'status'
      },
      {
        label: 'Branch',
        map: 'branch'
      },
      {
        label: 'Function',
        map: 'function'
      },
      {
        label: 'Product',
        map: 'product'
      },
      {
        label: 'CustommerName',
        map: 'custommerName'
      }
    ];

    scope.custRelColumnCollection = [
      {
        label: 'S No',
        map: 'SNo'
      },
      {
        label: 'Service Type',
        map: 'ServiceType'
      },
      {
        label: 'Category',
        map: 'Category'
      },
      {
        label: 'Sub Category',
        map: 'SubCategory'
      },
      {
        label: 'Refferral Memo',
        map: 'ReferralMemo'
      },
      {
        label: 'Agent Memo',
        map: 'AgentMemo'
      }
    ];

    scope.globalConfig = {
      isPaginationEnabled: false
    };

    scope.AddRemarksToGrid = function () {
      scope.custRelRowCollection = [];
      scope.custRelRowCollection = [{
        SNo: 1,
        ServiceType: scope.custRelationship.ServiceType == undefined ? '' : scope.custRelationship.ServiceType,
        Category: scope.custRelationship.Category == undefined ? '' : scope.custRelationship.Category,
        SubCategory: scope.custRelationship.SubCategory == undefined ? '' : scope.custRelationship.SubCategory,
        ReferralMemo: scope.custRelationship.Desc,
        AgentMemo: scope.custRelationship.AdditionalDesc
      }];

      scope.IsShowCustRelationGrid = true;
    }

    scope.gridOptions = {
      data: [],
      minWidth: 50,
      columnDefs: [
        { name: 'CampaignName', field: 'campaignName' },
        { name: 'CampaingDescription', field: 'campaingDescription' },
        { name: 'ValidityFrom', field: 'validityFrom' },
        { name: 'ValidatyTo', field: 'validatyTo' },
        { name: 'Status', field: 'status' },
        { name: 'Branch', field: 'branch' },
        { name: 'Function', field: 'function' },
        { name: 'Product', field: 'product' },
        { name: 'CustommerName', field: 'custommerName' },
      ],
      enableColumnMenus: false,
      enableSorting: false,
      enableColumnResizing: true,
      enableHorizontalScrollbar: 0,
      enableVerticalScrollbar: 0
    };

    scope.upSellgridOptions = {
      data: [],
      minWidth: 50,
      columnDefs: [
        { name: 'S No', field: 'SNo', width: "5%" },
        { name: 'Up-Sell', field: 'UpSell' },
        { name: 'Branch', field: 'Branch' },
        { name: 'DateTime', field: 'DateTime' },
        { name: 'Cust Name', field: 'CustName' },
        { name: 'Mobile', field: 'Mobile' },
        { name: 'City', field: 'City' },
        { name: 'State', field: 'State' },
        { name: 'Agent Memo', field: 'AgentMemo' },
        { name: 'Customer Memo', field: 'CustomerMemo' },
        { name: 'Remarks', field: 'Remarks' }
      ],
      enableColumnMenus: false,
      enableSorting: false,
      enableColumnResizing: true,
      enableHorizontalScrollbar: 1,
      enableVerticalScrollbar: 0
    };

    scope.xSellgridOptions = {
      data: [],
      minWidth: 50,
      columnDefs: [
        { name: 'S No', field: 'SNo', width: "5%" },
        { name: 'X-Sell', field: 'XSell' },
        { name: 'Branch', field: 'Branch' },
        { name: 'DateTime', field: 'DateTime' },
        { name: 'Cust Name', field: 'CustName' },
        { name: 'Mobile', field: 'Mobile' },
        { name: 'City', field: 'City' },
        { name: 'State', field: 'State' },
        { name: 'Agent Memo', field: 'AgentMemo', width: "15%" },
        { name: 'Customer Memo', field: 'CustomerMemo', width: "15%" },
        { name: 'Remarks', field: 'Remarks' }
      ],
      enableColumnMenus: false,
      enableSorting: false,
      enableColumnResizing: true,
      enableHorizontalScrollbar: 1,
      enableVerticalScrollbar: 0
    };

    scope.callHistData = [{
      SNo: 1, CustomerName: 'TestUser', Product: 'AUTO LOAN', CampaignName: 'Pre-Dial', TSEID: 'servion123',
      ResponseCode: 'Interested', CallResponse: 'Talked to the Customer', CallOutcome: 'Success', AgentRemarks: 'NA',
      LastCallDate: '2017-11-27', SupervisorRemarks: 'NA', Email: 'NA', SMS: 'NA'
    }];

    scope.callHistgridOptions = {
      data: 'callHistData',
      minWidth: 50,
      columnDefs: [
        { name: 'S No', field: 'SNo' },
        { name: 'Customer Name', field: 'CustomerName' },
        { name: 'Product', field: 'Product' },
        { name: 'Campaign Name', field: 'CampaignName' },
        { name: 'TSE ID', field: 'TSEID' },
        { name: 'Response Code', field: 'ResponseCode' },
        { name: 'Call Response', field: 'CallResponse' },
        { name: 'Call Outcome', field: 'CallOutcome' },
        { name: 'Agent Remarks', field: 'AgentRemarks' },
        { name: 'Last Call Date', field: 'LastCallDate' },
        { name: 'Supervisor Remarks', field: 'SupervisorRemarks' },
        { name: 'Email', field: 'Email' },
        { name: 'SMS', field: 'SMS' }
      ],
      enableColumnMenus: false,
      enableSorting: false,
      enableColumnResizing: true,
      enableHorizontalScrollbar: 1,
      enableVerticalScrollbar: 0
    };

    scope.xSellHistData = [{
      SNo: 1, Product: 'AUTO LOAN', DateTime: '2017-11-27', CustomerName: 'TestUser',
      MobileNumber: '7869435243', City: 'Chennai', ResponseCategory: 'Interested', CallResponse: 'Talked to the Customer', CallOutcome: 'Success', AgentRemarks: 'NA',
      CustomerRemarks: 'NA'
    }];

    scope.xSellHistgridOptions = {
      data: 'xSellHistData',
      minWidth: 50,
      columnDefs: [
        { name: 'S No', field: 'SNo' },
        { name: 'Product', field: 'Product' },
        { name: 'Date and Time', field: 'DateTime' },
        { name: 'Customer Name', field: 'CustomerName' },
        { name: 'Mobile Number', field: 'MobileNumber' },
        { name: 'City', field: 'City' },
        { name: 'Response Category', field: 'ResponseCategory' },
        { name: 'Call Response', field: 'CallResponse' },
        { name: 'Call Outcome', field: 'CallOutcome' },
        { name: 'Agent Remarks', field: 'AgentRemarks' },
        { name: 'Customer Remarks', field: 'CustomerRemarks' }
      ],
      enableColumnMenus: false,
      enableSorting: false,
      enableColumnResizing: true,
      enableHorizontalScrollbar: 1,
      enableVerticalScrollbar: 0
    };

    scope.crHistData = [{
      SNo: 1, Product: 'AUTO LOAN', DateTime: '2017-11-27', CustomerName: 'TestUser',
      MobileNumber: '7869435243', City: 'Chennai', ResponseCategory: 'Interested', CallResponse: 'Talked to the Customer', CallOutcome: 'Success', AgentRemarks: 'NA',
      CustomerRemarks: 'NA'
    }];

    scope.crHistgridOptions = {
      data: 'crHistData',
      minWidth: 50,
      columnDefs: [
        { name: 'S No', field: 'SNo' },
        { name: 'Product', field: 'Product' },
        { name: 'Date and Time', field: 'DateTime' },
        { name: 'Customer Name', field: 'CustomerName' },
        { name: 'Mobile Number', field: 'MobileNumber' },
        { name: 'City', field: 'City' },
        { name: 'Response Category', field: 'ResponseCategory' },
        { name: 'Call Response', field: 'CallResponse' },
        { name: 'Call Outcome', field: 'CallOutcome' },
        { name: 'Agent Remarks', field: 'AgentRemarks' },
        { name: 'Customer Remarks', field: 'CustomerRemarks' }
      ],
      enableColumnMenus: false,
      enableSorting: false,
      enableColumnResizing: true,
      enableHorizontalScrollbar: 1,
      enableVerticalScrollbar: 0
    };

    scope.emailHistData = [{
      CallHistoryId: 1, Email: 'AUTO LOAN', DynamicValues: '2017-11-27', TemplateId: 'TestUser',
      TemplateName: '7869435243', Function: 'Chennai', Product: 'Interested', Location: 'Talked to the Customer',
      Channel: 'Success', SentMode: 'NA', SentTime: 'NA'
    }];

    scope.emailHistgridOptions = {
      data: 'emailHistData',
      minWidth: 50,
      columnDefs: [
        { name: 'Call History ID', field: 'CallHistoryId' },
        { name: 'Email', field: 'Email' },
        { name: 'Dynamic Values', field: 'DynamicValues' },
        { name: 'Template ID', field: 'TemplateId' },
        { name: 'Template Name', field: 'TemplateName' },
        { name: 'Function', field: 'Function' },
        { name: 'Product', field: 'Product' },
        { name: 'Location', field: 'Location' },
        { name: 'Channel', field: 'Channel' },
        { name: 'Sent Mode', field: 'SentMode' },
        { name: 'Sent Time', field: 'SentTime' }
      ],
      enableColumnMenus: false,
      enableSorting: false,
      enableColumnResizing: true,
      enableHorizontalScrollbar: 1,
      enableVerticalScrollbar: 0
    };

    scope.smsHistData = [{
      CallHistoryId: 1, ANI: '7824212121', DynamicValues: '2017-11-27', TemplateId: 'TestUser',
      TemplateName: 'Template1', Function: 'AutoLoanReminder', Product: 'Interested', Location: 'Talked to the Customer',
      Channel: 'Success', SentMode: 'NA', SentTime: 'NA'
    }];

    scope.smsHistgridOptions = {
      data: 'smsHistData',
      minWidth: 50,
      columnDefs: [
        { name: 'Call History ID', field: 'CallHistoryId' },
        { name: 'ANI', field: 'ANI' },
        { name: 'Dynamic Values', field: 'DynamicValues' },
        { name: 'Template ID', field: 'TemplateId' },
        { name: 'Template Name', field: 'TemplateName' },
        { name: 'Function', field: 'Function' },
        { name: 'Product', field: 'Product' },
        { name: 'Location', field: 'Location' },
        { name: 'Channel', field: 'Channel' },
        { name: 'Sent Mode', field: 'SentMode' },
        { name: 'Sent Time', field: 'SentTime' }
      ],
      enableColumnMenus: false,
      enableSorting: false,
      enableColumnResizing: true,
      enableHorizontalScrollbar: 1,
      enableVerticalScrollbar: 0
    };
    scope.xSellgridOptions.onRegisterApi = function (gridapi) {
      scope.xSellGridAPI = gridapi;
    }

    scope.upSellgridOptions.onRegisterApi = function (gridapi) {
      scope.upSellGridAPI = gridapi;
    }

    scope.gridOptions.onRegisterApi = function (gridapi) {
      scope.mainGridAPI = gridapi;
    }

    scope.callHistgridOptions.onRegisterApi = function (gridapi) {
      scope.callHistGridAPI = gridapi;
    }

    scope.xSellHistgridOptions.onRegisterApi = function (gridapi) {
      scope.xSellHistGridAPI = gridapi;
    }

    scope.crHistgridOptions.onRegisterApi = function (gridapi) {
      scope.crHistGridAPI = gridapi;
    }

    scope.emailHistgridOptions.onRegisterApi = function (gridapi) {
      scope.emailHistGridAPI = gridapi;
    }

    scope.smsHistgridOptions.onRegisterApi = function (gridapi) {
      scope.smsHistGridAPI = gridapi;
    }

    vm.appFixGridOptions = {
      data: [],
      minWidth: 50,
      columnDefs: [
        { name: 'Field', field: 'field' },
        { name: 'Product', field: 'product' },
        { name: 'Field1', field: 'field1' },
        { name: 'DapId', field: 'dapid' },
        { name: 'Campaing Name', dispalyName: 'Campaing Name', field: 'campaingName', width: '15%' },
        { name: 'AppFix Date', dispalyName: 'AppFix Date', field: 'appFixDate' },
        { name: 'Sub-Product', dispalyName: 'Sub-Product', field: 'subProduct' }
      ],
      enableColumnMenus: false,
      enableSorting: false,
      enableColumnResizing: true,
      enableFullRowSelection: true,
      enableRowHeaderSelection: false,
      multiSelect: false,
      modifierKeysToMultiSelect: false,
      noUnselect: false,
      enableHorizontalScrollbar: 1,
      enableVerticalScrollbar: 0
    };

    vm.rowtobebinded = undefined;
    vm.appFixGridOptions.onRegisterApi = function (gridapi) {
      vm.appFixGridAPI = gridapi;
      vm.appFixGridAPI.selection.selectRow(vm.appFixGridOptions.data[0]);
      var rows = vm.appFixGridAPI.selection.getSelectedRows();

      //aravind's code to get the selected row elements is as below
      gridapi.selection.on.rowSelectionChanged(scope, function (row) {
        var msg = 'row selected ' + row.isSelected;

        vm.rowtobebinded = row.entity;
        vm.countRows = vm.appFixGridAPI.selection.getSelectedRows().length;
      });
    };

    scope.Refresh = function () {
      $interval(function () {
        scope.upSellGridAPI.core.handleWindowResize();
        scope.xSellGridAPI.core.handleWindowResize();
        // scope.mainGridAPI.core.handleWindowResize();
        scope.callHistGridAPI.core.handleWindowResize();
        scope.xSellHistGridAPI.core.handleWindowResize();
        vm.appFixGridAPI.core.handleWindowResize();
        scope.crHistGridAPI.core.handleWindowResize();
        scope.emailHistGridAPI.core.handleWindowResize();
        scope.smsHistGridAPI.core.handleWindowResize();
        scope.emailHistGridAPI.core.refresh();
        scope.smsHistGridAPI.core.refresh();
        scope.callHistGridAPI.core.refresh();
        scope.xSellHistGridAPI.core.refresh();
        scope.crHistGridAPI.core.refresh();
      }, 200, 1);
    };

  };

  $(document).ready(function () {
    $("div.bhoechie-tab-menu>div.list-group>div").click(function (e) {
      e.preventDefault();
      $(this).siblings('div.active').removeClass("active");
      $(this).addClass("active");
      var index = $(this).index();
      $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
      $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
    });
  });

  $(document).ready(function () {
    $("#word_count").on('keyup', function () {
      var words = this.value.match(/\S+/g).length;
      if (words > 250) {
        // Split the string on first 250 words and rejoin on spaces
        var trimmed = $(this).val().split(/\s+/, 250).join(" ");
        // Add a space at the end to keep new typing making new words
        $(this).val(trimmed + " ");
      }
      else {
        $('#display_count').text(words);
        $('#word_left').text(250 - words);
      }
    });
  });

})();